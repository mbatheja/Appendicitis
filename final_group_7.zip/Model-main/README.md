#running database
Open pgadmin4, setup database named "DSS"
In command prompt run full_backup.sql (in front end folder)

To run front end code download front end folder as is

In the command prompt window, set the directory to the front end folder
Change the file path in start_project.py to your path

Next run: python start_project.py

Now enter credentials: use physician usernames from credentials file 
and general password from hashed_passwords.ipynb and login


